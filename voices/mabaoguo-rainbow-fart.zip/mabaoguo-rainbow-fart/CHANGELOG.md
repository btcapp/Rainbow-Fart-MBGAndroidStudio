# Changelog

### [1.0.1](https://github.com/zthxxx/kugimiya-rainbow-fart/compare/v1.0.0...v1.0.1) (2020-06-29)


### docs

* update docs and typo keywords ([5ff4187](https://github.com/zthxxx/kugimiya-rainbow-fart/commit/5ff41873d6463106fbc8112b75075ecae3373987(type:docs)))


### ci

* add release action ([8ddf48e](https://github.com/zthxxx/kugimiya-rainbow-fart/commit/8ddf48ed6009b7d9f7dc8ced828c5fc4d6335290(type:ci)))
* init github action for build ([098ef33](https://github.com/zthxxx/kugimiya-rainbow-fart/commit/098ef3388266600c22117b28411ab80ad7b6cfa1(type:ci)))

## [1.0.0](https://github.com/zthxxx/kugimiya-rainbow-fart/compare/v0.0.1...v1.0.0) (2020-06-25)

- update all of voices
- split the keywords config
- optimize keywords-voices map
- add building process

## [0.0.1](https://github.com/zthxxx/kugimiya-rainbow-fart/tree/v0.0.1) (2020-06-21)

- init Kugimiya voice package
